ListOne = [1,2,3,4,5,6,7,8,9,10]
ListTwo = [2,4,6,8,10,12,14,16,18,20]

def addAndDisplayLists(list1,list2):
    for Getal1 in ListOne:
        print 
    for Getal2 in ListTwo:
        print (Getal1 + Getal2)
    
        

addAndDisplayLists(ListOne, ListTwo)