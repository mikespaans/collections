DagenWeek = ['Maandag', 'Dinsdag', 'Woensdag', 'Donderdag', 'Vrijdag', 'Zaterdag', 'Zondag']
print ("Alle dagen van de week zijn: " , DagenWeek)
print ("De werk dagen van de week zijn: " , DagenWeek[ :5])
print ("De Weekend dagen zijn: " , DagenWeek[ 5:])
DagenWeek.reverse()
print ("Alle dagen in de week in de omgekeerde volgorde zijn: " , DagenWeek)
print ("De Werkdagen in de omgekeerde volgorde zijn: " , DagenWeek[ 2:])
print ("De weekend dagen in de omgekeerde volgorde zijn: " , DagenWeek[ :2])